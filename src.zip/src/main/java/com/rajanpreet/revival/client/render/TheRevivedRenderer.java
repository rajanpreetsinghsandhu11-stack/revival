﻿package com.rajanpreet.revival.client.render;

import com.rajanpreet.revival.RevivalMod;
import com.rajanpreet.revival.entity.TheRevivedEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

public class TheRevivedRenderer extends MobEntityRenderer<TheRevivedEntity, BipedEntityModel<TheRevivedEntity>> {

    private static final Identifier TEXTURE = RevivalMod.id("textures/entity/the_revived.png");

    public TheRevivedRenderer(EntityRendererFactory.Context context) {
        super(context, new BipedEntityModel<>(context.getPart(EntityModelLayers.ZOMBIE)), 0.5F);
    }

    @Override
    public Identifier getTexture(TheRevivedEntity entity) {
        return TEXTURE;
    }
}
