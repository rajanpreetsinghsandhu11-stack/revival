﻿package com.rajanpreet.revival;

import com.rajanpreet.revival.entity.TheRevivedEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.BiomeModifications;
import net.fabricmc.fabric.api.biome.BiomeSelectors;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.Identifier;
import net.minecraft.world.Heightmap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RevivalMod implements ModInitializer {
    public static final String MOD_ID = "revival";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return new Identifier(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModRegistry.init();
        FabricDefaultAttributeRegistry.register(ModRegistry.THE_REVIVED, TheRevivedEntity.createAttributes());

        SpawnRestriction.register(
                ModRegistry.THE_REVIVED,
                SpawnRestriction.Location.ON_GROUND,
                Heightmap.Type.MOTION_BLOCKING_NO_LEAVES,
                HostileEntity::canSpawnInDark
        );

        BiomeModifications.addSpawn(
                BiomeSelectors.foundInOverworld(),
                SpawnGroup.MONSTER,
                ModRegistry.THE_REVIVED,
                6, 1, 1
        );

        LOGGER.info("Revival initialized.");
    }
}
